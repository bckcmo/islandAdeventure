/*
*Program Name: Final Project
*Author: Brendan Corazzin
*Date: 6/11/2017
*Description: This is the header file for the getYorN function.
*/

#ifndef GETYORN_HPP
#define GETYORN_HPP
#include "getYorN.hpp"

char getYorN();

#endif