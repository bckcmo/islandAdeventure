/*
*Program Name: Final Project
*Author: Brendan Corazzin
*Date: 6/4/2017
*Description: This is the header file for the getChar function.
*/

#ifndef GETCHAR_HPP
#define GETCHAR_HPP
#include <string>

char getChar();

#endif